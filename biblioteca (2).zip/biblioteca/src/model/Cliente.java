package model;

public class Cliente {
    private String nome;
    private int id;
    private String data_nasc;
    private String cpf;
    private String endereco;
    private String fone;


    public Cliente(String nome, int id, String data_nasc, String cpf, String endereco, String fone) {
        this.nome = nome;
        this.id = id;
        this.data_nasc = data_nasc;
        this.cpf = cpf;
        this.endereco = endereco;
        this.fone = fone;
    }

    public Cliente(){

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getData_nasc() {
        return data_nasc;
    }

    public void setData_nasc(String data_nasc) {
        this.data_nasc = data_nasc;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }
}
