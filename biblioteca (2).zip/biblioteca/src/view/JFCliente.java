package view;

import javax.swing.*;

public class JFCliente extends JFrame {
    public JFCliente(){
    }
    private JPanel jPanel1;
    private void initComponents(){
        jPanel1.setSize(300,200);
    }

}
