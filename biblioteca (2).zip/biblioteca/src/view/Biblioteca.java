package view;
import java.sql.SQLException;

import model.Livro;
import uteis.BdLivro;

public class Biblioteca {
    public static void main(String[] args) throws SQLException{
        /*Livro livro = new Livro(1,"senhor dos pasteis","Ronaldinho",
                1,2050,"2");
        BdLivro conexao = new BdLivro();
        conexao.adiciona_livro(livro);*/

        FormCliente formCliente = new FormCliente();
        formCliente.setVisible(true);

    }
}
