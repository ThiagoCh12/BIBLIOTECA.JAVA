package view;

import javax.swing.*;
import java.awt.*;

public class FormCliente extends JFrame {
    JPanel  pnlPrincipal, pnlPesquisar, pnlClientes, pnlDadosClientes, pnlBotoesClientes;
    JLabel lblPesquisar;
    JTextField txtPesquisar;
    JButton btnPesquisar, btnExcluir;
    JTable tblPesquisar;
    public FormCliente() {
        setTitle("Cadastro de cliente");
        setBounds(300,90, 900, 600);

        pnlPrincipal = new JPanel(new GridLayout(2,1,5,5));
        pnlPrincipal.setBackground(Color.BLUE);

        pnlPesquisar = new JPanel();
        pnlPesquisar.setBounds(300, 90, 900, 300);
        pnlPesquisar.setBackground((Color.YELLOW));
        lblPesquisar = new JLabel("Nome");
        txtPesquisar = new JTextField();
        btnPesquisar = new JButton("Pesquisar");
        txtPesquisar.setColumns(15);

        pnlClientes = new JPanel(new BorderLayout());
        pnlClientes.setBounds(300, 90, 900, 300);
        pnlClientes.setBackground(Color.PINK);

        pnlDadosClientes = new JPanel();
        pnlDadosClientes.setSize(600, 180);
        pnlDadosClientes.setBackground(Color.GREEN);

        pnlBotoesClientes = new JPanel();
        pnlBotoesClientes.setSize(280, 180);
        pnlBotoesClientes.setBackground(Color.BLACK);

        btnExcluir = new JButton("Excluir");


        pnlPrincipal.add(pnlPesquisar);
        pnlPrincipal.add(pnlClientes);






        Object [][] dados = {

                {"ID", "Nome", "Data nascimento", "Sexo", "Endereço", "Telefone"},
                {1, "Pietro", "09/03/1994", "M", "Rua das Oliveiras", "41995989696"},
                {2, "Pong", "09/04/2009", "M", "Rua das oliveiras", "9898956563"},
                {3, "Thiago", "20/08/2004", "M", "Rua das oliveiras", "5185621463"},
                {4, "Isaac", "14/03/1994", "M", "Rua das Oliveiras", "41995989696"},
                {5, "Victor", "29/04/2005", "M", "Rua das oliveiras", "9898956563"},
                {6, "Kenzo", "10/08/2005", "M", "Rua das oliveiras", "5185621463"}

        };
        String [] colunas = {"ID", "Nome", "Data nascimento", "Sexo", "Endereço", "Telefone"};
        tblPesquisar = new JTable(dados, colunas);

        tblPesquisar.getColumnModel().getColumn(0).setPreferredWidth(50);
        tblPesquisar.getColumnModel().getColumn(0).setResizable(false);
        tblPesquisar.getColumnModel().getColumn(1).setPreferredWidth(150);
        tblPesquisar.getColumnModel().getColumn(1).setResizable(false);
        tblPesquisar.getColumnModel().getColumn(2).setPreferredWidth(150);
        tblPesquisar.getColumnModel().getColumn(2).setResizable(false);
        tblPesquisar.getColumnModel().getColumn(3).setPreferredWidth(50);
        tblPesquisar.getColumnModel().getColumn(3).setResizable(false);
        tblPesquisar.getColumnModel().getColumn(4).setPreferredWidth(150);
        tblPesquisar.getColumnModel().getColumn(4).setResizable(false);
        tblPesquisar.getColumnModel().getColumn(5).setPreferredWidth(100);
        tblPesquisar.getColumnModel().getColumn(5).setResizable(false);


        pnlClientes.add(pnlBotoesClientes, BorderLayout.EAST);
        pnlClientes.add(pnlDadosClientes, BorderLayout.CENTER);

        pnlBotoesClientes.add(btnExcluir);

        pnlPesquisar.add(lblPesquisar);
        pnlPesquisar.add(txtPesquisar);
        pnlPesquisar.add(btnPesquisar);
        pnlPesquisar.add(tblPesquisar);

        pnlPrincipal.add(pnlClientes);

        getContentPane().add((pnlPrincipal));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
