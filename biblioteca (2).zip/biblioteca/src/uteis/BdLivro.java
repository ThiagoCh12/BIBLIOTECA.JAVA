package uteis;

import model.Livro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BdLivro {

    private Connection conexao;

    public BdLivro() throws SQLException {
        this.conexao = Conex.getConex();

    }
    public void adiciona_livro(Livro l) throws SQLException{
        String sql = "INSERT INTO livro(exemplar,autor,edicao,ano,disponibilidade)"
                + "VALUES(?,?,?,?,?)";
        PreparedStatement stmt;
        stmt = this.conexao.prepareStatement(sql);
        stmt.setString(1, l.getExemplar());
        stmt.setString(2, l.getAutor());
        stmt.setInt(3, l.getEdicao());
        stmt.setInt(4, l.getAno());
        stmt.setString(5, l.getDisponibilidade());
        stmt.execute();
        stmt.close();
    }
}
