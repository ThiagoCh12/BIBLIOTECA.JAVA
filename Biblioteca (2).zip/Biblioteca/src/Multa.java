import java.util.Date;

public class Multa {

    private String descricao;
    private Double multa;

    public Multa(String descricao, Double multa) {
        this.descricao = descricao;
        this.multa = multa;
    }
    public static double calcularMulta(Date dataDevolucaoEsperada, Date dataDevolucaoReal) {

        return 0;
    }

    public static boolean verificarAtraso(Date dataDevolucaoEsperada, Date dataDevolucaoReal) {

        return false;
    }
}
