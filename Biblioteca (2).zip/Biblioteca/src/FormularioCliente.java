
import javax.swing.*;
import java.awt.*;

    public class FormularioCliente {
        public static void main(String[] args) {
            JFrame frame = new JFrame("Cadastro de Cliente");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 200);

            JPanel panel = new JPanel();
            panel.setLayout(new GridLayout(3, 2));

            JLabel labelNome = new JLabel("Nome:");
            JTextField textFieldNome = new JTextField();

            JLabel labelEndereco = new JLabel("Endereço:");
            JTextField textFieldEndereco = new JTextField();

            JLabel labelTelefone = new JLabel("Telefone:");
            JTextField textFieldTelefone = new JTextField();

            JButton botaoCadastrar = new JButton("Cadastrar");

            panel.add(labelNome);
            panel.add(textFieldNome);
            panel.add(labelEndereco);
            panel.add(textFieldEndereco);
            panel.add(labelTelefone);
            panel.add(textFieldTelefone);

            frame.add(panel, BorderLayout.CENTER);
            frame.add(botaoCadastrar, BorderLayout.SOUTH);

            frame.setVisible(true);
        }
    }

