import java.sql.Connection;
public class TesteConex {

    public static void main(String[] args) {
        Conex conexao = new Conex();
        Connection conn = conexao.conectar();


    }
}
