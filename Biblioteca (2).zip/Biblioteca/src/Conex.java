import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Conex {
    String url = "jdbc:mysql://localhost:3306/Biblioteca";
    String usuario = "root";
    String senha = "";

    public Connection conectar() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Isso carrega o driver JDBC do MariaD
            System.out.printf("Conexao com banco realizada com sucesso.");// B.
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        try {
            conn = DriverManager.getConnection(url, usuario, senha);
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
}
