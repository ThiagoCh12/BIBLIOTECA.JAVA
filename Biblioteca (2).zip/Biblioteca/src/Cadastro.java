import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Cadastro {
    private Connection conex;

    public Cadastro(Connection conex) {
        this.conex = conex;
    }

    public void cadastrarCliente(){


    }

}
