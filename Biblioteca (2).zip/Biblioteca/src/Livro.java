public class Livro {

    private String exemplar;
    private String autor;
    private String disponibilidade;
    private int edicao;
    private int ano;

    public Livro(String exemplar, String autor,
                 String disponibilidade, int edicao,
                 int ano)
    {
        this.exemplar = exemplar;
        this.autor = autor;
        this.disponibilidade = disponibilidade;
        this.edicao = edicao;
        this.ano = ano;
    }
}
