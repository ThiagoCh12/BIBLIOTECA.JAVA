import java.util.Date;

public class Emprestimo {

    private Date data_emprestimo;
    private Date data_devolucao;

    public Emprestimo(Date data_emprestimo, Date data_devolucao) {
        this.data_emprestimo = data_emprestimo;
        this.data_devolucao = data_devolucao;
    }
}
